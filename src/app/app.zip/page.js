import NavBar from "./components/NavBar.js";
import styles from "./page.module.css";

export default function Home() {
  
  return (
  <div id="Homepage" className={styles.homepage}>
    <section className={styles.container}>
      <h1>Mes collections</h1>
      <NavBar />
    </section>
  </div>
  );
}