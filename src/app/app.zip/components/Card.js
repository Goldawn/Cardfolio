import { useState } from 'react';
import styles from './Card.module.css';
import CardModal from './CardModal';

export default function Card({ 
  card, 
  onAddToCollection, 
  updateQuantity, 
  onRemove, 
  currency = "eur" 
}) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => setIsModalOpen(false);

  // Vérification si la carte est recto-verso
  const isDoubleFaced = card.card_faces && card.card_faces.length > 1;

  // Sélection de l'image correcte
  const imageUrl = isDoubleFaced 
    ? card.card_faces[0]?.image_uris?.small || '' // Image du recto
    : card.image?.small || card.image_uris?.small || '';

  // Sélection du nom correct
  const cardName = isDoubleFaced ? card.card_faces[0]?.name || card.name.split(" // ")[0] : card.name;

  return (
    <div className={styles.card}>
      
      <img src={imageUrl} alt={cardName} onClick={handleOpenModal} />
      <h3>{cardName}</h3>
      {onAddToCollection && (
        <button onClick={() => onAddToCollection(card)}>Ajouter à la collection</button>
      )}
      {updateQuantity && (
        <>
        <div className={styles.details}>
          <p>Quantité : {card.quantity}</p>
          <p>Prix unitaire : {Number(card.price[currency])?.toFixed(2)} {currency === 'eur' ? '€' : '$'}</p>
          <p>Valeur totale : {(Number(card.price[currency]) * card.quantity).toFixed(2)} {currency === 'eur' ? '€' : '$'}</p>
        </div>
        <div className={styles.actionBox}>
          <div className={styles.quantityBtnBox}>
            <button className={styles.remove} onClick={() => updateQuantity(card.id, -1)}>-1</button>
            <button className={styles.add} onClick={() => updateQuantity(card.id, 1)}>+1</button>
          </div>
      </div>
      </>
      )}
      {onRemove && (
        <button className={styles.delete} onClick={() => onRemove(card.id)}>Supprimer</button>
      )}

      {isModalOpen && <CardModal card={card} onClose={handleCloseModal} />}
    </div>
  );
}
