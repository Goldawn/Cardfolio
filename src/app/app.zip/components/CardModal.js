"use client";

import { useState } from 'react';
import manaSymbols from '../assets/mock/mana.json';
import styles from './CardModal.module.css';

export default function CardModal({ card, onClose }) {
  if (!card) return null;

  const [flipped, setFlipped] = useState(false);

  // Fonction pour afficher les icônes de mana
  const parseManaCost = (manaCost) => {
    if (!manaCost) return null;

    return manaCost.split(/(\{[^}]+\})/g) // Sépare les symboles entre {}
        .filter(Boolean) // Supprime les entrées vides
        .map((symbol, index) => {
            const foundSymbol = manaSymbols.data.find(entry => entry.symbol === symbol);
            
            return foundSymbol ? (
                <img
                    key={index}
                    src={foundSymbol.svg_uri}
                    alt={symbol}
                    style={{ width: '20px', height: '20px', marginRight: '2px' }}
                />
            ) : symbol;
        });
}

  // Vérification si la carte est recto-verso
  const isDoubleFaced = card.image?.front && card.image?.back;

  // Sélection des images correctes
  const imageUrlFront = isDoubleFaced 
    ? card.image.front.large || ''
    : card.image?.large || card.image_uris?.large || '';

  const imageUrlBack = isDoubleFaced 
    ? card.image.back.large || ''
    : '';

  // Sélection dynamique des informations affichées
  const currentName = isDoubleFaced 
    ? flipped 
      ? card.name.split(" // ")[1] || card.name
      : card.name.split(" // ")[0] || card.name
    : card.name;

  const currentDescription = isDoubleFaced 
    ? flipped 
      ? card.card_faces?.[1]?.oracle_text || ''
      : card.card_faces?.[0]?.oracle_text || ''
    : card.oracle_text;

  const currentManaCost = isDoubleFaced
    ? flipped 
      ? card.card_faces?.[1]?.mana_cost || ''
      : card.card_faces?.[0]?.mana_cost || ''
    : card.mana_cost;

  const currentTypeLine = isDoubleFaced
    ? flipped 
      ? card.card_faces?.[1]?.type_line || ''
      : card.card_faces?.[0]?.type_line || ''
    : card.type_line;

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <button className={styles.closeButton} onClick={onClose}>×</button>
        <div className={styles.content}>
          {isDoubleFaced ? (
            <div className={styles.cardContainer}>
              <div className={`${styles.card} ${flipped ? styles.flipped : ''}`}>
                {/* Face avant */}
                <div className={styles.cardFace} style={{ backgroundImage: `url(${imageUrlFront})` }}>
                  <button className={styles.flipButton} onClick={() => setFlipped(true)}>
                    Voir le verso
                  </button>
                </div>
                {/* Face arrière */}
                <div className={styles.cardFace} style={{ backgroundImage: `url(${imageUrlBack})` }}>
                  <button className={styles.flipButton} onClick={() => setFlipped(false)}>
                    Voir le recto
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className={styles.imageContainer}>
              <img src={imageUrlFront} alt={card.name} className={styles.image} />
            </div>
          )}

          {/* Section détails mise à jour dynamiquement */}
          <div className={styles.details}>
            <h2>{currentName}</h2>
            <p><strong>Type :</strong> {currentTypeLine}</p>
            <p><strong>Coût de mana :</strong> {parseManaCost(card.mana_cost)}</p>
            <p><strong>Rareté :</strong> {card.rarity}</p>
            {currentDescription && <p><strong>Description :</strong> {currentDescription}</p>}
            {card.flavor_text && <p><em>{card.flavor_text}</em></p>}
            <p><strong>Numéro de collection :</strong> {card.collector_number}</p>

            {/* Couleurs de la carte */}
            {card.colors?.length > 0 && (
              <p><strong>Couleurs :</strong> {card.colors.join(", ")}</p>
            )}

            {/* Éditions alternatives */}
            {card.variation && <p><strong>Carte avec variation spéciale</strong></p>}
            {card.frame_effects?.length > 0 && (
              <p><strong>Effets de cadre :</strong> {card.frame_effects.join(", ")}</p>
            )}

            {/* Légalités en formats */}
            <p><strong>Formats légaux :</strong></p>
            <ul>
              {Object.entries(card.legalities)
                .filter(([_, legality]) => legality === "legal")
                .map(([format]) => (
                  <li key={format}>{format}</li>
                ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
