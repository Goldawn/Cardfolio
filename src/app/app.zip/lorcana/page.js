export default function LorcanaHome() {
    return <h1>Collection Lorcana</h1>;
  }