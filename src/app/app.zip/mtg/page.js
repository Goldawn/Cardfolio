"use client";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { loadCollection, saveCollection } from '../services/Collection.js';
import { fetchCardPrice } from '../services/pricing.js';
import { exportToJSON } from '../services/Export.js';
import Card from '../components/Card.js';
import styles from './page.module.css';

export default function Collection() {
  const [collection, setCollection] = useState([]);
  const [updating, setUpdating] = useState(false);
  const [currency, setCurrency] = useState(localStorage.getItem('currency') || 'eur');

  const updateQuantity = (cardId, delta) => {
    const updatedCollection = collection.map((card) =>
      card.id === cardId ? { ...card, quantity: Math.max(1, card.quantity + delta) } : card
    );
    setCollection(updatedCollection);
    saveCollection(updatedCollection);
  };

  const removeCard = (cardId) => {
    const updatedCollection = collection.filter((card) => card.id !== cardId);
    setCollection(updatedCollection);
    saveCollection(updatedCollection);
  };

  useEffect(() => {
    setCollection(loadCollection());
  }, []);

  const handleExport = () => {
    if (collection.length === 0) {
      alert('Aucune carte à exporter !');
      return;
    }
    exportToJSON(collection, 'fondations-mtg.json');
  };

  // Fonction pour changer la devise
  const toggleCurrency = () => {
    const newCurrency = currency === 'eur' ? 'usd' : 'eur';
    setCurrency(newCurrency);
    localStorage.setItem('currency', newCurrency);
  };

  // Fonction pour mettre à jour les prix
  const updatePrices = async () => {
    setUpdating(true);
    const updatedCollection = await Promise.all(
      collection.map(async (card) => {
        const newPrice = await fetchCardPrice(card.name);
        return {
          ...card,
          price: {
            usd: newPrice.usd || 0,
            eur: newPrice.eur || 0
          }
        };
      })
    );
    setCollection(updatedCollection);
    saveCollection(updatedCollection);
    setUpdating(false);
  };

  // Calcul du total de la collection
  const totalValue = collection.reduce((acc, card) => acc + (Number(card.price[currency]) * card.quantity), 0);

  return (
    <div id={styles.collectionPage}>
      <Link className={styles.addCardsBtn} href="/mtg/importer">Importer de nouvelles cartes</Link>
      <h1>Ma Collection</h1>
      <h2>Valeur totale : {totalValue.toFixed(2)} {currency === 'eur' ? '€' : '$'}</h2>
      <div className={styles.buttonContainer}>
        <button className={styles.update} onClick={toggleCurrency}>
          Afficher en {currency === 'eur' ? 'USD $' : 'EUR €'}
        </button>
        <button className={styles.update} onClick={updatePrices} disabled={updating}>
          {updating ? 'Mise à jour en cours...' : 'Mettre à jour les prix'}
        </button>
        <button onClick={handleExport}>Export to JSON</button>
      </div>
      <div className={styles.cardContainer}>
        {collection.length === 0 && <p>Votre collection est vide.</p>}
        {collection.map((card) => {
          const isDoubleFaced = !!card.image?.front && !!card.image?.back;

          return (
            <Card 
              key={card.id} 
              card={{
                ...card,
                image_uris: {
                  small: isDoubleFaced ? card.image.front.small : card.image.small,
                  normal: isDoubleFaced ? card.image.front.normal : card.image.normal,
                  large: isDoubleFaced ? card.image.front.large : card.image.large
                }
              }}
              updateQuantity={updateQuantity} 
              onRemove={removeCard} 
              currency={currency} 
            />
          );
        })}
      </div>
    </div>
  );
}
