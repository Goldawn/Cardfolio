'use client';
import { useEffect, useState } from 'react';
import { fetchSets, fetchSetCards, fetchMoreCards } from '../../services/Scryfall.js';

import Card from '../../components/Card.js';
import Link from 'next/link';
import { addCardToCollection } from "../../services/Collection.js";
import styles from './page.module.css';

export default function MTGHome() {
  const [sets, setSets] = useState([]);
  const [filteredSets, setFilteredSets] = useState([]);
  const [selectedSet, setSelectedSet] = useState('');
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [nextPage, setNextPage] = useState();

  useEffect(() => {
    const loadSets = async () => {
      const allSets = await fetchSets();
      setSets(allSets);
    };
    loadSets();
  }, []);

  const handleInputChange = (e) => {
    const query = e.target.value.toLowerCase();
    setFilteredSets(sets.filter((set) => set.name.toLowerCase().includes(query)));
  };

  const handleSetSelect = async (setCode) => {
    setSelectedSet(setCode);
  };

  useEffect(() => {
    const loadCards = async () => {
      setLoading(true);
      const cardsData = await fetchSetCards(selectedSet, 'en');
      setCards(cardsData.data);
      if (cardsData.has_more) {
        setNextPage(cardsData.next_page);
      }
      setLoading(false);
    };
    loadCards();
  }, [selectedSet]);

  useEffect(() => {
    if (nextPage) {
      const loadMoreCards = async () => {
        setLoading(true);
        const moreCardsData = await fetchMoreCards(nextPage);
        setCards([...cards, ...moreCardsData.data]);
        if (moreCardsData.has_more) {
          setNextPage(moreCardsData.next_page);
        }
        setLoading(false);
      };
      loadMoreCards();
    }
  }, [nextPage]);

  return (
    <div>
      <Link href="/mtg">Voir ma collection</Link>
      <h1>Magic: The Gathering</h1>
      <div className={styles.inputContainer}>
        <input type="text" placeholder="Recherchez un set..." onChange={handleInputChange} />
        {filteredSets.length > 0 && (
          <ul id={styles.scrollbar}>
            {filteredSets.map((set) => (
              <li key={set.code} onClick={() => handleSetSelect(set.code)}>
                {set.name} ({set.code})
              </li>
            ))}
          </ul>
        )}
      </div>
      {loading && <p>Chargement des cartes...</p>}
      {selectedSet && (
        <div>
          <h2>Cartes du set : {selectedSet}</h2>
          <div id={styles.cardContainer}>
            {cards.map((card) => (
              <Card 
              key={card.id}
              card={{
                ...card,
                image_uris: {
                  small: card.image_uris?.small || card.card_faces?.[0]?.image_uris?.small || '',
                  normal: card.image_uris?.normal || card.card_faces?.[0]?.image_uris?.normal || '',
                  large: card.image_uris?.large || card.card_faces?.[0]?.image_uris?.large || ''
                }
              }} 
              onAddToCollection={addCardToCollection} 
            />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
