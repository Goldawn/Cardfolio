export default function PokemonHome() {
    return <h1>Collection Pokemon</h1>;
  }