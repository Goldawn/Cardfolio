"use client"
import { fetchCardPrice } from "./pricing.js";

// Sauvegarder la collection dans le localStorage
export const saveCollection = (collection) => {
    localStorage.setItem('mtgCollection', JSON.stringify(collection));
  };
  
  // Charger la collection depuis le localStorage
  export const loadCollection = () => {
    const collection = localStorage.getItem('mtgCollection');
    return collection ? JSON.parse(collection) : [];
  };
  
  // Ajouter une carte à la collection
  export const addCardToCollection = async (card) => {
    const collection = loadCollection();
  
    // Vérifier si la carte est déjà dans la collection
    const existingCard = collection.find((item) => item.id === card.id);
    if (existingCard) {
      // Si elle existe, augmenter la quantité
      existingCard.quantity += 1;
    } else {
      // Récupérer le prix de la carte
      const price = await fetchCardPrice(card.name);
  
      // Vérification si la carte est recto-verso
      const isDoubleFaced = card.card_faces && card.card_faces.length > 1;
  
      // Création de l'objet carte enrichi
      const newCard = {
        id: card.id,
        name: card.name,
        set: card.set,
        lang: card.lang || 'en',
        quantity: 1,
        price: {
          usd: price.usd || 0,
          eur: price.eur || 0
        },
        image: isDoubleFaced
          ? {
              front: {
                small: card.card_faces[0]?.image_uris?.small || '',
                normal: card.card_faces[0]?.image_uris?.normal || '',
                large: card.card_faces[0]?.image_uris?.large || ''
              },
              back: {
                small: card.card_faces[1]?.image_uris?.small || '',
                normal: card.card_faces[1]?.image_uris?.normal || '',
                large: card.card_faces[1]?.image_uris?.large || ''
              }
            }
          : {
              small: card.image_uris?.small || '',
              normal: card.image_uris?.normal || '',
              large: card.image_uris?.large || ''
            },
        colors: card.colors || [], // Liste des couleurs
        type_line: card.type_line || '', // Type de la carte
        mana_cost: card.mana_cost || '', // Coût en mana
        rarity: card.rarity || '', // Rareté
        oracle_text: card.oracle_text || (isDoubleFaced ? `${card.card_faces[0]?.oracle_text || ''}\n${card.card_faces[1]?.oracle_text || ''}` : ''), // Texte d'Oracle
        collector_number: card.collector_number || '', // Numéro de collection
        variation: card.variation || false, // Indique si la carte est une variation
        frame_effects: card.frame_effects || [], // Effets de frame (ex : showcase, borderless...)
        legalities: card.legalities || {} // Formats où la carte est jouable
      };
  
      collection.push(newCard);
    }
  
    saveCollection(collection);
  };